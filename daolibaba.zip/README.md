# daolibaba


<script>

    // slider.init();


    // var app = new Vue({
    //     el: '#mallCategoryBody',
    //     data: {
    //         message: 'Hello Vue!'
    //     }
    // })
</script> -->
