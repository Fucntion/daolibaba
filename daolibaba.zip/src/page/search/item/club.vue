<template>

</template>

<script>
    export default {
        name: "mall"
    }
</script>

<style scoped>

</style>
