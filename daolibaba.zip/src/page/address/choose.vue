<!-- 选择已有地址 -->
<template>
  <div>222231231231232122222</div>
</template>

<script>
  import {address} from "../../service/getData";

  export default {
  data () {
    return {
    };
  },

  components: {},
  created(){
    address({

    }).then(res=>{

    })
  },
  computed: {},



  methods: {}
}

</script>
<style lang='less' scoped>
</style>
