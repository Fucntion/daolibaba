<!--  -->
<template>
<div>
    
</div>
</template>

<script>
export default {
  data() {
    return {};
  },
    props:['lists'],
  components: {},

  computed: {},

  methods: {}
};
</script>
<style lang='less' scoped>

</style>