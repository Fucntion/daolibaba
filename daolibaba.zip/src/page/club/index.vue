<template>
  <transition name="router-fade" mode="out-in">
    <router-view></router-view>
  </transition>
</template>

<script>


  export default {
    data () {
      return {

      };
    },

    components: {},

    computed: {},

    created(){

    },

    methods: {

    }
  }

</script>
<style lang='less' scoped>
</style>
