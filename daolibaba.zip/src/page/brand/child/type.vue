<template>
<div>
  fdsafsa312321312312313123123131
</div>
</template>

<script>
    export default {
        name: "type"
    }
</script>

<style scoped>

</style>
