<!--  -->
<template>
<div>
    <div  class="full-list flex">
        <router-link :to="'/mall/detail/'+item.id" class="item"  v-for="item in lists" :key="item.itemid">
            <div class="thumb-box" >
                <img :src="item.thumb" class="thumb" />
            </div>
            <dl class="info">
                <dd class="name info-line"><span ><strong>{{item.title|cutstr(30)}}</strong></span></dd>
                <dd class="price info-line">￥{{item.price}}</dd>
                <dd class="count info-line"><span class="count-order">总共售出{{item.sales}}{{item.unit||'件'}}</span><span class="count-comment">{{item.comments}}条评价</span></dd>
                <dd><span>{{item.company}}</span></dd>
            </dl>
        </router-link>
    </div>
</div>
</template>

<script>
export default {
  name:'mallList',
  data() {
    return {

    };
  },
    props:['lists'],
  components: {},

  computed: {},

  methods: {}
};
</script>
<style lang='less' scoped>
.info-line{
  margin-bottom: 4px !important;
}
  .thumb{
    margin-top: 4px;
  }
</style>
