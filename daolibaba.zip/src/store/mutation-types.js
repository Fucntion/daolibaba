export const SET_USERINFO = 'SET_USERINFO'
export const ADD_ADDRESS = 'ADD_ADDRESS'
export const DEL_ADDRESS = 'DEL_ADDRESS'
export const SET_ADDRESS = 'SET_ADDRESS'
export const CHOOSE_ADDRESS = 'CHOOSE_ADDRESS'

export const SHOW_MASK = 'SHOW_MASK'
export const CLOSE_MASK = 'CLOSE_MASK'
export const SET_AREA = 'SET_AREA'

