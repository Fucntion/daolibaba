export const provinces = require('./provinces');
export const citys = require('./cities');
export const areas = require('./areas');

export default {
  provinces,
  citys,
  areas
}
